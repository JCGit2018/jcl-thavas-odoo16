# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class costes_en_destino(models.Model):
#     _name = 'costes_en_destino.costes_en_destino'
#     _description = 'costes_en_destino.costes_en_destino'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100
