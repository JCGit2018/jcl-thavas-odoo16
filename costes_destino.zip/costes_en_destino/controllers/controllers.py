# -*- coding: utf-8 -*-
# from odoo import http


# class CostesEnDestino(http.Controller):
#     @http.route('/costes_en_destino/costes_en_destino', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/costes_en_destino/costes_en_destino/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('costes_en_destino.listing', {
#             'root': '/costes_en_destino/costes_en_destino',
#             'objects': http.request.env['costes_en_destino.costes_en_destino'].search([]),
#         })

#     @http.route('/costes_en_destino/costes_en_destino/objects/<model("costes_en_destino.costes_en_destino"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('costes_en_destino.object', {
#             'object': obj
#         })
