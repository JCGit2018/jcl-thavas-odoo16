# Part of Odoo. See LICENSE file for full copyright and licensing details.

import logging

from odoo import _, api, models,fields
from odoo.exceptions import ValidationError

from odoo.addons.payment import utils as payment_utils

_logger = logging.getLogger(__name__)


class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'
    
    banesco_transaction_id = fields.Char(string="Id transacción" )
    
    banesco_approval_code = fields.Char( string="Codigo aprobación")
    
    banesco_capture_code = fields.Char( string="Codigo captura")
    
    banesco_reversal_reason = fields.Char( string="Razón reverso")
    

    def _send_payment_request(self):
        """ Override of payment to simulate a payment request.

        Note: self.ensure_one()

        :return: None
        """
        super()._send_payment_request()
        if self.provider != 'banesco':
            return

        # The payment request response would normally transit through the controller but in the end,
        # all that interests us is the reference. To avoid making a localhost request, we bypass the
        # controller and handle the fake feedback data directly.
        self._handle_feedback_data('banesco', {'reference': self.reference})

    @api.model
    def _get_tx_from_feedback_data(self, provider, data):
        """ Override of payment to find the transaction based on dummy data.

        :param str provider: The provider of the acquirer that handled the transaction
        :param dict data: The dummy feedback data
        :return: The transaction if found
        :rtype: recordset of `payment.transaction`
        :raise: ValidationError if the data match no transaction
        """
        tx = super()._get_tx_from_feedback_data(provider, data)
        if provider != 'banesco':
            return tx

        reference = data.get('reference')
        tx = self.search([('reference', '=', reference), ('provider', '=', 'banesco')])
        if not tx:
            raise ValidationError(
                "Banesco: " + _("No transaction found matching reference %s.", reference)
            )
        return tx

    def _process_feedback_data(self, data):
        """ Override of payment to process the transaction based on dummy data.

        Note: self.ensure_one()

        :param dict data: The dummy feedback data
        :return: None
        :raise: ValidationError if inconsistent data were received
        """
        super()._process_feedback_data(data)
        if self.provider != "banesco":
            return
        
        response_content = data.get('response')
        with open('/home/odoo/src/user/datospago.txt', 'w') as temp_file:
            temp_file.write("%s\n" % response_content)
        
        if not response_content: #error en conexion
            raise ValidationError("Banesco: " + _("Error en validación, revise los datos introducidos"))
            
        payment_state = response_content.status
        if payment_state =='AUTHORIZED':
            self._set_done()
        elif payment_state =='DECLINED':    
            self._set_canceled() #cancelar transaccion  
        else:
             #error_code = response_content.get('x_response_reason_text')
             error_code='00',
             status_code='ERROR'
             _logger.info(
                "received data with invalid status code %s and error code %s",
                status_code, error_code
            )
             self._set_error(
                "Banesco: " + _(
                    "Received data with status code \"%(status)s\" and error code \"%(error)s\"",
                    status=status_code, error=error_code
                )
            )

        #self._set_authorized()#solo autorizadadice que no es compatible revisar
        #self._set_pending() #transac pendiente
        if self.tokenize:
            token = self.env['payment.token'].create({
                'acquirer_id': self.acquirer_id.id,
                'name': payment_utils.build_token_name(payment_details_short=data['cc_summary']),
                'partner_id': self.partner_id.id,
                'acquirer_ref': 'fake acquirer reference',
                'verified': True,
            })
            
            self.token_id = token.id
