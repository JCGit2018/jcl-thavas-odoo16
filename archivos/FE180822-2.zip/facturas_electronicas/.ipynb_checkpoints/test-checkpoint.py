# Modulo que brinda funciones de SOAP
import zeep
# Link del WS
wsdl = 'http://demoemision.thefactoryhka.com.pa/ws/obj/v1.0/Service.svc?singleWsdl'
# Establecemos el cliente como el WS
cliente = zeep.Client(wsdl=wsdl)


# Declaramos el diccionario que pasa los datos de factura
datos = dict(
tokenEmpresa="SOLICITAR",
tokenPassword="SOLICITAR",
documento=dict(
codigoSucursalEmisor="0001",
tipoSucursal="1",
datosTransaccion=dict({
"tipoEmision": "01",
"tipoDocumento": "01",
"numeroDocumentoFiscal": "0000001",
"puntoFacturacionFiscal": "001",
"naturalezaOperacion": "01",
"tipoOperacion": 1,
"destinoOperacion": 1,
"formatoCAFE": 1,
"entregaCAFE": 1,
"envioContenedor": 1,
"procesoGeneracion": 1,
"tipoVenta": 1,
"fechaEmision": "2021-10-14T09:00:00-05:00",
"cliente": {
"tipoClienteFE": "02",
"tipoContribuyente": 1,
"numeroRUC": 89337412,
"pais": "PA",
"correoElectronico1": "",
"razonSocial": "MIGUEL GÓMEZ"
}
}),
listaItems=dict(
item=[{
"descripcion": "Esta es una prueba 1",
"cantidad": "1.00",
"precioUnitario": "20.00",
"precioUnitarioDescuento": " ",
"precioItem": "20.00",
"valorTotal": "21.40",
"codigoGTIN": "0",
"cantGTINCom": "0.99",
"codigoGTINInv": "0",
"tasaITBMS": "01",
"valorITBMS": "1.40",
"cantGTINComInv": "1.00"
}, {
"descripcion": "Esta es una prueba 2",
"cantidad": "1.00",
"precioUnitario": "20.00",
"precioUnitarioDescuento": " ",
"precioItem": "20.00",
"valorTotal": "21.40",
"codigoGTIN": "0",
"cantGTINCom": "0.99",
"codigoGTINInv": "0",
"tasaITBMS": "01",
"valorITBMS": "1.40",
"cantGTINComInv": "1.00"
}]
),
totalesSubTotales=dict({
"totalPrecioNeto": "40.00",
"totalITBMS": "2.80",
"totalMontoGravado": "2.80",
"totalDescuento": "",
"totalAcarreoCobrado": "",
"valorSeguroCobrado": "",
"totalFactura": "42.80",
"totalValorRecibido": "42.80",
"vuelto": "0.00",
"tiempoPago": "1",
"nroItems": "2",
"totalTodosItems": "42.80"},
listaFormaPago=dict(
formaPago=[
{"formaPagoFact": "02",
"descFormaPago": " ",
"valorCuotaPagada": "21.40"},
{"formaPagoFact": "02",
"descFormaPago": " ",
"valorCuotaPagada": "21.40"}
]
)
)
)
)

# Declaramos el metodo a usar, recorremos el diccionario y lo enviamos
res = (cliente.service.Enviar(**datos))
# Se imprime la respuesta a la solicitud del servicio
print(res)




