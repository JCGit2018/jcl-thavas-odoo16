/* global AdyenCheckout */
odoo.define('aspl_payment_cybersource_ee.cs_payment_form', require => {
    'use strict';

    const core = require('web.core');
    const checkoutForm = require('payment.checkout_form');
    const manageForm = require('payment.manage_form');

    const _t = core._t;
    const cyber_sourcesMixin = {


        /**
         * Prepare the inline form of Adyen for direct payment.
         *
         * @override method from payment.payment_form_mixin
         * @private
         * @param {string} provider - The provider of the selected payment option's acquirer
         * @param {number} paymentOptionId - The id of the selected payment option
         * @param {string} flow - The online payment flow of the selected payment option
         * @return {Promise}
         */
         _processDirectPayment: function (provider, acquirerId, processingValues) {
            if (provider !== 'cybersource') {
                return this._super(...arguments);
            }
            processingValues.cc_number = document.getElementById('cc_number').value;
            processingValues.cc_holder_name = document.getElementById('cc_holder_name').value;
            processingValues.cc_expiry = document.getElementById('cc_expiry_mm').value + '/' + document.getElementById('cc_expiry_yy').value;
            processingValues.cc_cvc = document.getElementById('cc_cvc').value;
            return this._rpc({
                route: '/payment/cybersource/s2s/create_json_3ds',
                params: {
                    processingValues
                },
            }).then(() => {
                window.location = '/payment/status';
            });
            
        },

        _prepareInlineForm: function (provider, paymentOptionId, flow) {
            if (flow === 'token') {
                return Promise.resolve();
            }
            this._setPaymentFlow('direct');
            return Promise.resolve()
        },

    };

    checkoutForm.include(cyber_sourcesMixin);
    manageForm.include(cyber_sourcesMixin);
});
