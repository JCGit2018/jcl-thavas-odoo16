from odoo import http
from odoo.http import request
from odoo import models, fields, api

class parametros(models.Model):
    
      parametros = self.env['payment.acquirer'].sudo().search([('provider','=','banesco')])
      print(parametros.banesco_merchant_id)
