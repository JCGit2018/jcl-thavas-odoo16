from CyberSource import *
import os
import json
from importlib.machinery import SourceFileLoader

config_file =  "Configuration.py"
configuration = SourceFileLoader("module.name", config_file).load_module()

# To delete None values in Input Request Json body
def del_none(d):
    for key, value in list(d.items()):
        if value is None:
            del d[key]
        elif isinstance(value, dict):
            del_none(value)
    return d

def simple_authorizationinternet(flag,**data):
    
    #return
    clientReferenceInformationCode = data['codCliente']
    clientReferenceInformation = Ptsv2paymentsClientReferenceInformation(
        code = clientReferenceInformationCode
    )

    processingInformationCapture = False
    if flag:
        processingInformationCapture = True
    
    processingInformation = Ptsv2paymentsProcessingInformation(
        capture = processingInformationCapture
    )

    paymentInformationCardNumber = data['numTarjeta']#"4111111111111111"
    paymentInformationCardExpirationMonth = data['expiraMes'] # "12"
    paymentInformationCardExpirationYear = data['expiraAno'] #"2031" año completo
    paymentInformationCardSecurityCode = data['codTarjeta']#"123"
    paymentInformationCard = Ptsv2paymentsPaymentInformationCard(
        number = paymentInformationCardNumber,
        expiration_month = paymentInformationCardExpirationMonth,
        expiration_year = paymentInformationCardExpirationYear,
        security_code = paymentInformationCardSecurityCode
    )

    paymentInformation = Ptsv2paymentsPaymentInformation(
        card = paymentInformationCard.__dict__
    )

    orderInformationAmountDetailsTotalAmount = data['monto'] #"132.21"
    orderInformationAmountDetailsCurrency = data['moneda'] # "USD"
    orderInformationAmountDetails = Ptsv2paymentsOrderInformationAmountDetails(
        total_amount = orderInformationAmountDetailsTotalAmount,
        currency = orderInformationAmountDetailsCurrency
    )

    orderInformationBillToFirstName = data['nombreCliente']#"Juan"
    orderInformationBillToLastName = data['apellidoCliente']#"Doe"
    orderInformationBillToAddress1 = data['direccion']#"1 Market St"
    orderInformationBillToLocality = data['ciudadCliente']#"san francisco"
    orderInformationBillToAdministrativeArea = data['estadoCliente']#"CA"
    orderInformationBillToPostalCode = data['codPostalCliente']#"94105"
    orderInformationBillToCountry = data['paisCliente']#"US"
    orderInformationBillToEmail = data['emailCliente']#"test@cybs.com"
    orderInformationBillToPhoneNumber = data['telCliente']#"4158880000"
    orderInformationBillTo = Ptsv2paymentsOrderInformationBillTo(
        first_name = orderInformationBillToFirstName,
        last_name = orderInformationBillToLastName,
        address1 = orderInformationBillToAddress1,
        locality = orderInformationBillToLocality,
        administrative_area = orderInformationBillToAdministrativeArea,
        postal_code = orderInformationBillToPostalCode,
        country = orderInformationBillToCountry,
        email = orderInformationBillToEmail,
        phone_number = orderInformationBillToPhoneNumber
    )

    orderInformation = Ptsv2paymentsOrderInformation(
        amount_details = orderInformationAmountDetails.__dict__,
        bill_to = orderInformationBillTo.__dict__
    )

    requestObj = CreatePaymentRequest(
        client_reference_information = clientReferenceInformation.__dict__,
        processing_information = processingInformation.__dict__,
        payment_information = paymentInformation.__dict__,
        order_information = orderInformation.__dict__
    )


    requestObj = del_none(requestObj.__dict__)
    requestObj = json.dumps(requestObj)


    try:
        config_obj = configuration.Configuration()
        client_config = config_obj.get_configuration()
        api_instance = PaymentsApi(client_config)
        return_data, status, body = api_instance.create_payment(requestObj)

        print("\nAPI RESPONSE CODE : ", status)
        print("\nAPI RESPONSE BODY : ", body)
        with open('/home/odoo/src/user/respuestapago.txt', 'w') as temp_file:
            temp_file.write("%s\n" % return_data)


        return return_data
    except Exception as e:
        print("\nException when calling PaymentsApi->create_payment: %s\n" % e)
        with open('/home/odoo/src/user/error_respuestapago.txt', 'w') as temp_file:
            temp_file.write("%s\n" % type(e))


if __name__ == "__main__":
    datos= {
            'nombre': 'juan',
            'codCliente':'ClI001',
            'numTarjeta': "4111111111111111",
            'expiraMes':'12',
            'expiraAno':'2031',
            'monto':"132.21",
            'moneda': "USD",
            'nombreCliente': "Juan",
            'apellidoCliente':"Doe",
            'direccion': "1 Market St",
            'ciudadCliente':"san francisco",
            'estadoCliente':"CA",
            'codPostalCliente':"94105",
            'paisCliente':"US",
            'emailCliente' : "test@cybs.com",
            'telCliente': "4158880000",
            'codTarjeta':'123'
           }
    simple_authorizationinternet(True,**datos)
