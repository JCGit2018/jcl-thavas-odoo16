# -*- coding: utf-8 -*-
#################################################################################
# Author      : Acespritech Solutions Pvt. Ltd. (<www.acespritech.com>)
# Copyright(c): 2012-Present Acespritech Solutions Pvt. Ltd.
# All Rights Reserved.
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#################################################################################
import logging

from odoo import fields, models

_logger = logging.getLogger(__name__)


class PaymentAcquirer(models.Model):
    _inherit = 'payment.acquirer'

    provider = fields.Selection(selection_add=[('cybersource', 'CyberSource')], ondelete={'cybersource': 'set default'})
    cybersource_merchant_id = fields.Char(required_if_provider='cybersource', string="Merchant id")
    cybersource_key = fields.Char(required_if_provider='cybersource', string="Key")

    def _get_default_payment_method_id(self):
        self.ensure_one()
        if self.provider != 'cybersource':
            return super(PaymentAcquirer, self)._get_default_payment_method_id()
        return self.env.ref('aspl_payment_cybersource_ee.payment_method_cyberSource').id
