import qrcode
img = qrcode.make("Hola desde Recursos Python!")

'/home/odoo/src/user/output.png'
f = open("/home/odoo/src/user/output.png", "wb")
img.save(f)
f.close()

#otra implementacion

data = 'QR Code using make() fuction'
  
img = qrcode.make(data) 
  
img.save('/home/odoo/src/user/MyQRCode1.png')


'''
Versión: Este parámetro es un número entero de 1 a 40 que controla el tamaño del Código QR(el más pequeño, la versión 1, es una matriz de 21 × 21).

error_correction:   este parámetro controla la corrección de errores que se utiliza para el código QR. Hay las siguientes cuatro constantes disponibles para esto:
qrcode.constants.ERROR_CORRECT_L : Se pueden corregir aproximadamente un 7% o menos de errores.
qrcode.constants.ERROR_CORRECT_M(predeterminado) : se pueden corregir aproximadamente un 15% o menos de errores.
qrcode.constants.ERROR_CORRECT_Q : Se pueden corregir aproximadamente un 25% o menos de errores.
qrcode.constants.ERROR_CORRECT_H : Se pueden corregir aproximadamente un 30% o menos de errores.

box_size: este parámetro controla cuántos píxeles tiene cada "caja" del código QR.

border: El parámetro border controla cuántos cuadros de grosor debe tener el borde(el valor predeterminado es 4, que es el mínimo en la especificación).

add_data(): este método se usa para agregar datos al objeto QRCode. Toma los datos a codificar como parámetro.

make(): este método con (fit = True) garantiza que se utilice toda la dimensión del código QR, incluso si 
nuestros datos de entrada podrían caber en un número menor de casillas.

make_image(): este método se utiliza para convertir el objeto QRCode en un archivo de imagen. Se necesitan los parámetros opcionales fill_color y back_color para establecer el color de primer plano y de fondo.

'''

data = "GeeksforGeeks"
  
qr = qrcode.QRCode(version = 1, 
                   box_size = 10, 
                   border = 5) 
  
qr.add_data(data) 
  
qr.make(fit = True) 
img = qr.make_image(fill_color = 'red', 
                    back_color = 'white') 
  
img.save('/home/odoo/src/user/MyQRCode2.png')

