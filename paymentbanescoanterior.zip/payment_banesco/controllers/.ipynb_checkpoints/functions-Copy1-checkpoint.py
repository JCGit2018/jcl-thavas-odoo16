from uuid import uuid4
from datetime import datetime, timezone
import requests

#import datetime
from base64 import b64encode, b64decode
from hashlib import sha256
import hashlib
import hmac



transaction_uuid = uuid4().hex

url = "https://testsecureacceptance.cybersource.com/pay"

def create_sha256_signature(key, message):
    """
    Signs an HMAC SHA-256 signature to a message with Base 64
    encoding. This is required by CyberSource.
    """
    #return b64encode(hmac.new(key.encode(), message.encode("utf-8"), hashlib.sha256).digest()).decode()
    
    digest = hmac.new(
        key.encode(),
        msg=message.encode(),
        digestmod=sha256,
    ).digest()
    #print( b64encode(digest).decode())
    return b64encode(digest).decode()

def create_signature(key, message):
        #ig_value = "".join(signature_list)
        sig_value_string = str(message)
        sig_value_utf = bytes(sig_value_string, encoding='utf-8')
        secret = b64decode(key)
        hash_value = hmac.new(secret, sig_value_utf, sha256)
        signature = b64encode(hash_value.digest()).decode("utf-8")
        return signature


def sign_fields_to_context(fields, context):
    """
    Builds the list of file names and data to sign, and created the
    signature required by CyberSource.
    """
    
    CYBERSOURCE_SECRET_KEY = '7da6b7dc11374e72b6fefa30c66f0766738aab3d2d8d4897b5eae4597a5153b74594a9789a31442ca26b73151da9cc9714a87a0b13bf4bd39a7cdf794ea3a76b17724df25e0a4974bd8b34db570e37a2db15f8f50f6849878c85fca6d10c7da7f7978d4acb6345a5a7d5eac78536df6afe219a7d0bd644b1aa2ee73032fed471'
    
    #fields['signed_date_time'] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    signed_field_names = []
    data_to_sign = []
    for key, value in fields.items():
        signed_field_names.append(key)
    #print(fields)
    #print()
    # After adding all the included fields, we need to also add
    # `unsigned_field_names` and `signed_field_names` to the data
    # to be signed.
    #signed_field_names.append('unsigned_field_names')
    #fields['unsigned_field_names'] = ''
    #signed_field_names.append('signed_field_names')
    #fields['signed_field_names'] = ','.join(signed_field_names)

    # Build the fields into a list to sign, which will become
    # a string when joined by a comma
    for key, value in fields.items():
        data_to_sign.append(f'{key}={value}')
    
    #print(data_to_sign)
    
    context['fields'] = fields
    #context['signature'] = create_sha256_signature(
    #    CYBERSOURCE_SECRET_KEY,
    #    ','.join(data_to_sign),
    #)
    #print(','.join(data_to_sign))
    context['signature'] = create_sha256_signature(
        CYBERSOURCE_SECRET_KEY,
        ','.join(data_to_sign)
    )
    
    #context['url'] = settings.CYBERSOURCE_URL

    return context


payload={'access_key': '62faa2c32b7039bab7f658c14339bdfb',
'profile_id': '74EDC3E4-2B1F-4EAA-BE80-6A8AA95FA648',
'transaction_uuid': transaction_uuid,
'signed_field_names': 'access_key,profile_id,transaction_uuid,signed_field_names,unsigned_field_names,signed_date_time,locale,transaction_type,reference_number,amount,currency',
'unsigned_field_names':'',
'signed_date_time': datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),         
#'signed_date_time': '2022-09-21T20:51:50Z',         
'locale': 'en',
'transaction_type': 'authorization',
'reference_number': '1663793514034',
'amount': '100.00',
'currency': 'USD',
        }
files=[

]

#response = requests.request("POST", url, headers=headers, data=payload, files=files)
context = dict()
#print(response.text)
to_send= sign_fields_to_context(payload,context)
print(to_send['signature'])

#print(to_send['fields']['signed_date_time'])


headers = {
 #'Accept' : 'application/hal+json;charset=utf-8',
 #'Accept-Encoding': '*',
 #'Content-Type':'application/json' ,  
 #'Host' : "https://testsecureacceptance.cybersource.com",
 #"v-c-merchant-id": 'bc_5808831146',  
 #'Date': datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
 #'signature' : to_send['signature']
 #"User-Agent" : "Mozilla/5.0"
} 

#payload['signed_date_time'] = to_send['fields']['signed_date_time']
payload['signature'] = to_send['signature']
print(payload)

response = requests.request("POST", url, headers=headers, data=payload, files=files)
print(response.text)
