# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import http, _
from odoo.http import request
import os
import json
from odoo.exceptions import UserError
from uuid import uuid4
from datetime import datetime, timezone
from base64 import b64encode, b64decode
from hashlib import sha256
import hashlib
import hmac
import logging
import pprint

_logger = logging.getLogger(__name__)

def create_sha256_signature(key, message):
    """
    Signs an HMAC SHA-256 signature to a message with Base 64
    encoding. This is required by CyberSource.
    """
    
    digest = hmac.new(
        key.encode(),
        msg=message.encode(),
        digestmod=sha256,
    ).digest()
    return b64encode(digest).decode()


def sign_fields_to_context(fields, context, secret_key):
    """
    Builds the list of file names and data to sign, and created the
    signature required by CyberSource.
    """
    
    
    
    signed_field_names = []
    data_to_sign = []
    for key, value in fields.items():
        signed_field_names.append(key)
    # Build the fields into a list to sign, which will become
    # a string when joined by a comma
    for key, value in fields.items():
        data_to_sign.append(f'{key}={value}')
    
    #print(data_to_sign)
    
    context['fields'] = fields
    context['signature'] = create_sha256_signature(
        secret_key,
        ','.join(data_to_sign)
    )
    

    return context

def generate_signature(key,**data):
    #print(data)
    #print(key)
    context = dict()
    to_send = sign_fields_to_context(data,context,key)
    return to_send['signature']



class PaymentBanescoController(http.Controller):
    
    @http.route('/payment/banesco/authenticate', type='http', methods=['GET', 'POST'], auth="public", website=True, sitemap=False)
    def index(self,**kw):
      data= json.loads(kw.get('response_content', -1))
      
      with open('/home/odoo/src/user/data_transac.txt', 'w') as temp_file:
                temp_file.write("%s\n" % data)
  
      
      acquirer_id = data['acquirer_id']
        
      parametros = request.env['payment.acquirer'].sudo().search([('id','=', acquirer_id)])

      if parametros.state=='test':
          url_a_usar = parametros.banesco_url_test
      elif parametros.state=='enabled':
          url_a_usar = parametros.banesco_url_prod
  
      #url_a_usar ='https://testsecureacceptance.cybersource.com/pay'  
      #secret_key = parametros.banesco_secret_key
      secret_key = '7da6b7dc11374e72b6fefa30c66f0766738aab3d2d8d4897b5eae4597a5153b74594a9789a31442ca26b73151da9cc9714a87a0b13bf4bd39a7cdf794ea3a76b17724df25e0a4974bd8b34db570e37a2db15f8f50f6849878c85fca6d10c7da7f7978d4acb6345a5a7d5eac78536df6afe219a7d0bd644b1aa2ee73032fed471'  #tomar del modelo
      secret_key =  parametros.banesco_secret_key
     
      orderTotalAmount = data['amount']
       
      moneda= request.env['res.currency'].sudo().search([('id','=', data['currency_id'])])
        
        #convesrion a USD si la transaccion se hace en otra moneda
      if moneda.name !='USD':
         orderTotalAmount =  "{0:.2f}".format(moneda.inverse_rate * data['amount'])
      
      if parametros.capture_manually:
          transaction = 'authorization'
      else:
          transaction = 'sale' 
            
      transaction_uuid = uuid4().hex   
      my_time= datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
      
      payload= {
            'access_key': parametros.banesco_access_key, #tomar del modelo
            'profile_id': parametros.banesco_profile_id,
            'transaction_uuid': transaction_uuid,
            'signed_field_names': 'access_key,profile_id,transaction_uuid,signed_field_names,unsigned_field_names,signed_date_time,locale,transaction_type,reference_number,amount,currency',
            'unsigned_field_names':'',
            'signed_date_time': my_time,         
            'locale': 'es-mx',
            'transaction_type': transaction, #se escoge por el check de captura manual
            'reference_number': data['reference'],
            'amount': orderTotalAmount,
            'currency': 'USD'
      }
     
      my_signature = generate_signature(secret_key,**payload)
      
      return http.request.render('payment_banesco.authenticate', {
            'host_url': url_a_usar,
            'access_key': parametros.banesco_access_key,
            'profile_id': parametros.banesco_profile_id,
            'transaction_uuid': transaction_uuid,
            'signed_field_names': 'access_key,profile_id,transaction_uuid,signed_field_names,unsigned_field_names,signed_date_time,locale,transaction_type,reference_number,amount,currency',
            'unsigned_field_names':'',
            'signed_date_time': my_time,         
            'locale': 'es-mx',
            'transaction_type': transaction, #se escoge por el check de captura amnual
            'reference_number': data['reference'],
            'amount': orderTotalAmount,
            'currency': 'USD',
            'signature':my_signature
      })

        
    _return_url = '/payment/banesco/return'

    @http.route(
        _return_url, type='http', auth='public', methods=['POST'], csrf=False, save_session=False
    )
    def banesco_return_from_redirect(self, **data):
        _logger.info("received notification data:\n%s", pprint.pformat(data))
        with open('/home/odoo/src/user/respuesta_host.txt', 'w') as temp_file:
                temp_file.write("%s\n" % data)
        
        request.env['payment.transaction'].sudo()._handle_feedback_data('banesco', data)
    
        return request.redirect('/payment/status')        

            
