from uuid import uuid4
from datetime import datetime, timezone


#import datetime
from base64 import b64encode, b64decode
from hashlib import sha256
import hashlib
import hmac



transaction_uuid = uuid4().hex


def create_sha256_signature(key, message):
    """
    Signs an HMAC SHA-256 signature to a message with Base 64
    encoding. This is required by CyberSource.
    """
    
    digest = hmac.new(
        key.encode(),
        msg=message.encode(),
        digestmod=sha256,
    ).digest()
    return b64encode(digest).decode()


def sign_fields_to_context(fields, context, secret_key):
    """
    Builds the list of file names and data to sign, and created the
    signature required by CyberSource.
    """
    
    
    
    signed_field_names = []
    data_to_sign = []
    for key, value in fields.items():
        signed_field_names.append(key)
    # Build the fields into a list to sign, which will become
    # a string when joined by a comma
    for key, value in fields.items():
        data_to_sign.append(f'{key}={value}')
    
    #print(data_to_sign)
    
    context['fields'] = fields
    #context['signature'] = create_sha256_signature(
    #    CYBERSOURCE_SECRET_KEY,
    #    ','.join(data_to_sign),
    #)
    #print(','.join(data_to_sign))
    context['signature'] = create_sha256_signature(
        secret_key,
        ','.join(data_to_sign)
    )
    

    return context

def generate_signature(key,**data):
    #print(data)
    #print(key)
    context = dict()
    to_send = sign_fields_to_context(data,context,key)
    return to_send['signature']

payload={'access_key': '62faa2c32b7039bab7f658c14339bdfb',
'profile_id': '74EDC3E4-2B1F-4EAA-BE80-6A8AA95FA648',
'transaction_uuid': '53612',
'signed_field_names': 'access_key,profile_id,transaction_uuid,signed_field_names,unsigned_field_names,signed_date_time,locale,transaction_type,reference_number,amount,currency',
'unsigned_field_names':'',
#'signed_date_time': datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),         
'signed_date_time': '2022-09-21T18:28:49Z',         
'locale': 'en',
'transaction_type': 'authorization',
'reference_number': '1663784934035',
'amount': '100.00',
'currency': 'USD',
        }

payload1={'access_key': '62faa2c32b7039bab7f658c14339bdfb',
'profile_id': '74EDC3E4-2B1F-4EAA-BE80-6A8AA95FA648',
'transaction_uuid': '0f3ecead9f634c08a391ba07b3fa71ad',
'signed_field_names': 'access_key,profile_id,transaction_uuid,signed_field_names,unsigned_field_names,signed_date_time,locale,transaction_type,reference_number,amount,currency',
'unsigned_field_names':'',
#'signed_date_time': datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),         
'signed_date_time': '2022-09-23T18:39:55Z',         
'locale': 'en',
'transaction_type': 'sale',
'reference_number': 'S00446-78',
'amount': '101.60',
'currency': 'USD',
        }
'''
    <input type="text" id="access_key" name="access_key" value="62faa2c32b7039bab7f658c14339bdfb"/>
<input type="text" id="profile_id" name="profile_id" value="74EDC3E4-2B1F-4EAA-BE80-6A8AA95FA648"/>
<input type="text" id="transaction_uuid" name="transaction_uuid" value="632ded3867f8b"/>
<input type="text" id="signed_field_names" name="signed_field_names" value="access_key,profile_id,transaction_uuid,signed_field_names,unsigned_field_names,signed_date_time,locale,transaction_type,reference_number,amount,currency"/>
<input type="text" id="unsigned_field_names" name="unsigned_field_names" value=""/>
<input type="text" id="signed_date_time" name="signed_date_time" value="2022-09-23T17:30:32Z"/>
<input type="text" id="locale" name="locale" value="en"/>
<input type="text" id="transaction_type" name="transaction_type" value="authorization"/>
<input type="text" id="reference_number" name="reference_number" value="1663954758872"/>
<input type="text" id="amount" name="amount" value="100.00"/>
<input type="text" id="currency" name="currency" value="USD"/>
<input type="text" id="submit" name="submit" value="Submit"/>
<input type="text" id="signature" name="signature" value="6t4LyZR5zlCjXiK7AzmL/myxWiJ1pXU9bUYyJSCXkuk="/>
6t4LyZR5zlCjXiK7AzmL/myxWiJ1pXU9bUYyJSCXkuk=
<input type="submit" id="submit" value="Confirm"/>
0kLRbBJyz259jIBaF2TbOrGNwFXDm4v+DIJokxnPHm8=
0kLRbBJyz259jIBaF2TbOrGNwFXDm4v+DIJokxnPHm8=
'''

CYBERSOURCE_SECRET_KEY = '7da6b7dc11374e72b6fefa30c66f0766738aab3d2d8d4897b5eae4597a5153b74594a9789a31442ca26b73151da9cc9714a87a0b13bf4bd39a7cdf794ea3a76b17724df25e0a4974bd8b34db570e37a2db15f8f50f6849878c85fca6d10c7da7f7978d4acb6345a5a7d5eac78536df6afe219a7d0bd644b1aa2ee73032fed471'

print(generate_signature(CYBERSOURCE_SECRET_KEY,**payload1))

'62faa2c32b7039bab7f658c14339bdfb,74EDC3E4-2B1F-4EAA-BE80-6A8AA95FA648,53612,access_key,profile_id,transaction_uuid,signed_field_names,unsigned_field_names,signed_date_time,locale,transaction_type,reference_number,amount,currency,,2022-09-21T18:28:49Z,en,authorization,1663784934035,'
'100.00,USD,Submit'

    
    