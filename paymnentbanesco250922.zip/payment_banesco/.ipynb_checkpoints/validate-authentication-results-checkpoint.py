from CyberSource import *
import os
import json
from importlib.machinery import SourceFileLoader

config_file = "Configuration.py"
configuration = SourceFileLoader("module.name", config_file).load_module()

# To delete None values in Input Request Json body
def del_none(d):
    for key, value in list(d.items()):
        if value is None:
            del d[key]
        elif isinstance(value, dict):
            del_none(value)
    return d

def validate_authentication_results():
    clientReferenceInformationCode = "TC50171_3"
    clientReferenceInformationPartnerDeveloperId = "7891234"
    clientReferenceInformationPartnerSolutionId = "89012345"
    clientReferenceInformationPartner = Riskv1decisionsClientReferenceInformationPartner(
        developer_id = clientReferenceInformationPartnerDeveloperId,
        solution_id = clientReferenceInformationPartnerSolutionId
    )

    clientReferenceInformation = Riskv1decisionsClientReferenceInformation(
        code = clientReferenceInformationCode,
        partner = clientReferenceInformationPartner.__dict__
    )

    orderInformationAmountDetailsCurrency = "USD"
    orderInformationAmountDetailsTotalAmount = "102.21"
    orderInformationAmountDetails = Riskv1authenticationsOrderInformationAmountDetails(
        currency = orderInformationAmountDetailsCurrency,
        total_amount = orderInformationAmountDetailsTotalAmount
    )


    orderInformationLineItems = []
    orderInformationLineItems1 = Riskv1authenticationresultsOrderInformationLineItems(
        unit_price = "10",
        quantity = 2,
        tax_amount = "32.40"
    )

    orderInformationLineItems.append(orderInformationLineItems1.__dict__)

    orderInformation = Riskv1authenticationresultsOrderInformation(
        amount_details = orderInformationAmountDetails.__dict__,
        line_items = orderInformationLineItems
    )

    paymentInformationCardType = "001"
    paymentInformationCardExpirationMonth = "01"
    paymentInformationCardExpirationYear = "2025"
    paymentInformationCardNumber = "4456530000001096"
    paymentInformationCard = Riskv1authenticationresultsPaymentInformationCard(
        type = paymentInformationCardType,
        expiration_month = paymentInformationCardExpirationMonth,
        expiration_year = paymentInformationCardExpirationYear,
        number = paymentInformationCardNumber
    )

    paymentInformation = Riskv1authenticationresultsPaymentInformation(
        card = paymentInformationCard.__dict__
    )

    consumerAuthenticationInformationAuthenticationTransactionId = "UerGCzfpaO8zwsHYzO40"
    #consumerAuthenticationInformationSignedPares = "eNqdmFmT4jgSgN+J4D90zD4yMz45PEFVhHzgA2zwjXnzhQ984Nvw61dAV1"
    consumerAuthenticationInformation = Riskv1authenticationresultsConsumerAuthenticationInformation(
        authentication_transaction_id = consumerAuthenticationInformationAuthenticationTransactionId,
        #signed_pares = consumerAuthenticationInformationSignedPares
    )

    requestObj = ValidateRequest(
        client_reference_information = clientReferenceInformation.__dict__,
        order_information = orderInformation.__dict__,
        payment_information = paymentInformation.__dict__,
        consumer_authentication_information = consumerAuthenticationInformation.__dict__
    )


    requestObj = del_none(requestObj.__dict__)
    requestObj = json.dumps(requestObj)


    try:
        config_obj = configuration.Configuration()
        client_config = config_obj.get_configuration()
        api_instance = PayerAuthenticationApi(client_config)
        return_data, status, body = api_instance.validate_authentication_results(requestObj)

        print("\nAPI RESPONSE CODE : ", status)
        print("\nAPI RESPONSE BODY : ", body)
        print("\nAPI RESULT DATA : ", return_data)

        return return_data
    except Exception as e:
        print("\nException when calling PayerAuthenticationApi->validate_authentication_results: %s\n" % e)

if __name__ == "__main__":
    validate_authentication_results()
